const FRAME_RATE = 30;
const GRID_SIZE = 30;
const ADRESS = "http://localhost";

module.exports = {
  FRAME_RATE,
  GRID_SIZE,
  ADRESS
}